# Push notifications setup

Step-by-step guide to enable Web Push so drivers get notifications when a new task is assigned, even with the PWA backgrounded or the phone locked.

## Architecture refresher

```
Dispatcher assigns order
        ↓
   /tasks/{id}/assigned_driver_id changes (null → driver UID)
        ↓
   notifyDriverOnAssignment Cloud Function fires (database trigger)
        ↓
   Function reads driver's push_subscription from /drivers/{uid}/push_subscription
        ↓
   Sends Web Push payload to Apple/FCM endpoint via web-push library (signed with VAPID private key)
        ↓
   Phone OS delivers to PWA's service worker
        ↓
   Service worker shows notification on lock screen
```

---

## Step 1: Generate VAPID keys

VAPID = Voluntary Application Server Identification. A keypair that proves your server is the legit sender of pushes. The public key gets baked into the driver app; the private key stays on the server.

From the `xpizza-functions/` folder:

```bash
cd xpizza-functions
npm install         # if you haven't installed since adding web-push to package.json
npm run vapid
```

You'll see something like:

```
=======================================
Public Key:
BNxK...verylongstring...

Private Key:
6gLm...anotherlongstring...
=======================================
```

**Save both immediately.** The public key goes into your driver app source and is non-secret. The private key must stay secret — if it leaks, attackers can send pushes to your drivers.

## Step 2: Add VAPID keys to `.env`

Open `xpizza-functions/.env` (the one with your `MAKE_SECRET` from before) and add:

```
VAPID_PUBLIC_KEY=BNxK...
VAPID_PRIVATE_KEY=6gLm...
VAPID_SUBJECT=mailto:your-real-email@example.com
```

The subject must be a real `mailto:` address or `https://` URL — push services use it to contact you about delivery problems. Use any email you actually check.

Save and close.

## Step 3: Paste the public VAPID key into the driver app

Open `xpizza-driver/index.html` and find this line (around line 1485):

```js
const VAPID_PUBLIC_KEY = 'REPLACE_WITH_VAPID_PUBLIC_KEY';
```

Replace the placeholder with your **public** key (NOT the private one):

```js
const VAPID_PUBLIC_KEY = 'BNxK...verylongstring...';
```

Save the file. The private key stays out of the driver app — only the public key goes here.

## Step 4: Deploy the Cloud Function

```bash
cd xpizza-functions
npm run deploy
```

This deploys both `createOrder` (existing) and the new `notifyDriverOnAssignment` (database trigger). First-time deployment of a database trigger can take 2-3 minutes.

When done, verify both functions exist:

```bash
firebase functions:list
```

You should see:
- `createOrder` (HTTPS)
- `notifyDriverOnAssignment` (Realtime Database trigger)

## Step 5: Deploy the driver app

Drag the `xpizza-driver/` folder onto the Netlify deploy zone for `xpizzadriver.netlify.app`. Suggested deploy message: `v1.5.0 — push notifications`.

After deploy, on your phone:
1. **Force-quit the existing PWA** (swipe up + away)
2. **Reopen** from the home screen icon

You should now see a yellow banner on the off-shift screen:
```
🔔 Habilita notificaciones
   Para recibir alertas cuando llegue un pedido nuevo.
                                                [Habilitar]
```

## Step 6: Enable + test

On the phone:

1. Tap **Habilitar** in the banner
2. The browser asks for notification permission → tap **Allow**
3. Banner turns green: "✓ Notificaciones activadas"
4. Tap **Iniciar turno** to start your shift

From the dispatcher (other tab/computer):

5. Submit a test order through `xpizzaorders.netlify.app` (or use one already in queue)
6. Assign it to the driver who just enabled notifications
7. **Lock the phone** to test background delivery
8. Within 1-3 seconds, the phone should display a notification: "¡Nuevo pedido! · [Customer name] · L[total]"
9. Tap the notification → opens the PWA to the active task

If the notification arrives → it's working. 🎉

---

## iOS specifics — read before testing on iPhone

iOS Web Push is more restrictive than Android. Three hard requirements:

1. **iOS 16.4 or later** (March 2023). Older iOS doesn't support Web Push at all. Check Settings → General → About → Software Version.
2. **PWA must be installed via "Add to Home Screen"**. Just opening the URL in Safari doesn't count — push notifications won't work. The driver app's banner detects this and tells the user to install.
3. **Permission must be requested via user gesture**. Our "Habilitar" button satisfies this — don't try to call `Notification.requestPermission()` on page load.

Behavior quirks:
- iOS may delay push delivery by 5-30 seconds when the phone is in low-power mode
- iOS aggressively kills background service workers; the push wakes them briefly
- If the PWA is in the foreground when a push arrives, iOS may NOT show the system notification (it assumes the app handles it). This is OK for our case — the driver is already looking at the screen.

---

## Android specifics

Much smoother:
- Notifications work in Chrome/Edge whether the PWA is installed or not
- Vibration pattern (`[200, 100, 200, 100, 200]`) works as set in the service worker
- Background delivery is reliable

---

## Troubleshooting

### Banner stays on "Habilitar" after I tap it

Browser denied permission. On iPhone: Settings → Safari → Notifications → check that your domain is allowed. Or uninstall + reinstall the PWA.

### "Push no configurado en este build"

You forgot to replace `VAPID_PUBLIC_KEY` in `xpizza-driver/index.html`. Check that placeholder is gone.

### No push arrives even though banner says enabled

Run the function logs:
```bash
firebase functions:log -n 20
```

Look for `notifyDriver:` lines.

- `notifyDriver: VAPID keys not configured` → `.env` is missing keys, redeploy
- `notifyDriver: driver {uid} has no push subscription` → driver enabled in browser but the subscription didn't save to Firebase. Have them disable + re-enable. Verify `/drivers/{uid}/push_subscription` exists in Firebase Console.
- `notifyDriver: push failed for {uid}, status=410` → the subscription is dead (driver uninstalled the PWA, or browser revoked it). Function auto-cleared it. Driver needs to re-enable.
- `notifyDriver: push failed for {uid}, status=401` → VAPID keys mismatch. Likely you regenerated keys but only updated one place. Public key in driver app must match `VAPID_PUBLIC_KEY` in function `.env`.

### Function doesn't fire on assignment

Check that `notifyDriverOnAssignment` is deployed:
```bash
firebase functions:list
```

If only `createOrder` shows, the new function didn't deploy. Re-run `npm run deploy` and watch for errors.

### "Permission denied" appears after grant

The browser is in incognito mode (notifications disabled), or the user has notifications blocked at the OS level. iOS: Settings → Notifications → Safari (or your installed PWA name).

---

## Rotating VAPID keys

If you ever need to rotate (e.g., suspected leak):

1. Generate new keys: `npm run vapid`
2. Update `.env` with new keys
3. Update `VAPID_PUBLIC_KEY` constant in `xpizza-driver/index.html`
4. Deploy both: function + driver
5. **All existing driver subscriptions become invalid.** Drivers need to disable + re-enable notifications in the app to get a new subscription tied to the new keys.

This is why rotation should be rare. If unsure, treat the private key like any other production secret.
